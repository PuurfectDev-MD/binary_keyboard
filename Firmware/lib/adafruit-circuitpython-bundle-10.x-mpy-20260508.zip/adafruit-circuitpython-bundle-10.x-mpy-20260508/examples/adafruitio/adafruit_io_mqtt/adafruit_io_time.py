# SPDX-FileCopyrightText: 2021 ladyada for Adafruit Industries
# SPDX-License-Identifier: MIT

# Adafruit IO provides some built-in MQTT topics
# for obtaining the current server time, if you don't have
# access to a RTC module.
import time
from os import getenv

import adafruit_connection_manager
import adafruit_minimqtt.adafruit_minimqtt as MQTT
import board
import busio
import neopixel
from adafruit_esp32spi import adafruit_esp32spi, adafruit_esp32spi_wifimanager
from digitalio import DigitalInOut

from adafruit_io.adafruit_io import IO_MQTT

# Get WiFi details and Adafruit IO keys, ensure these are setup in settings.toml
# (visit io.adafruit.com if you need to create an account, or if you need your Adafruit IO key.)
ssid = getenv("CIRCUITPY_WIFI_SSID")
password = getenv("CIRCUITPY_WIFI_PASSWORD")
aio_username = getenv("ADAFRUIT_AIO_USERNAME")
aio_key = getenv("ADAFRUIT_AIO_KEY")

### WiFi ###

# If you are using a board with pre-defined ESP32 Pins:
esp32_cs = DigitalInOut(board.ESP_CS)
esp32_ready = DigitalInOut(board.ESP_BUSY)
esp32_reset = DigitalInOut(board.ESP_RESET)

# If you have an externally connected ESP32:
# esp32_cs = DigitalInOut(board.D9)
# esp32_ready = DigitalInOut(board.D10)
# esp32_reset = DigitalInOut(board.D5)

spi = busio.SPI(board.SCK, board.MOSI, board.MISO)
esp = adafruit_esp32spi.ESP_SPIcontrol(spi, esp32_cs, esp32_ready, esp32_reset)
"""Use below for Most Boards"""
status_pixel = neopixel.NeoPixel(board.NEOPIXEL, 1, brightness=0.2)  # Uncomment for Most Boards
"""Uncomment below for ItsyBitsy M4"""
# status_pixel = dotstar.DotStar(board.APA102_SCK, board.APA102_MOSI, 1, brightness=0.2)
# Uncomment below for an externally defined RGB LED
# import adafruit_rgbled
# from adafruit_esp32spi import PWMOut
# RED_LED = PWMOut.PWMOut(esp, 26)
# GREEN_LED = PWMOut.PWMOut(esp, 27)
# BLUE_LED = PWMOut.PWMOut(esp, 25)
# status_pixel = adafruit_rgbled.RGBLED(RED_LED, BLUE_LED, GREEN_LED)
wifi = adafruit_esp32spi_wifimanager.WiFiManager(esp, ssid, password, status_pixel=status_pixel)


# Define callback functions which will be called when certain events happen.
def connected(client):
    # Connected function will be called when the client is connected to Adafruit IO.
    # This is a good place to subscribe to feed changes.  The client parameter
    # passed to this function is the Adafruit IO MQTT client so you can make
    # calls against it easily.
    print("Connected to Adafruit IO!")

    # Subscribe to time/seconds topic
    # https://io.adafruit.com/api/docs/mqtt.html#time-seconds
    io.subscribe_to_time("seconds")

    # Subscribe to time/millis topic
    # https://io.adafruit.com/api/docs/mqtt.html#time-millis
    io.subscribe_to_time("millis")

    # Subscribe to time/ISO-8601 topic
    # https://io.adafruit.com/api/docs/mqtt.html#time-iso-8601
    io.subscribe_to_time("iso")

    # Subscribe to time/hours topic
    # NOTE: This topic only publishes once every hour.
    # https://io.adafruit.com/api/docs/mqtt.html#adafruit-io-monitor
    io.subscribe_to_time("hours")


def disconnected(client):
    # Disconnected function will be called when the client disconnects.
    print("Disconnected from Adafruit IO!")


def publish(client, userdata, topic, pid):
    # This method is called when the client publishes data to a feed.
    print(f"Published to {topic} with PID {pid}")
    if userdata is not None:
        print("Published User data: ", end="")
        print(userdata)


def message(client, feed_id, payload):
    # Message function will be called when a subscribed feed has a new value.
    # The feed_id parameter identifies the feed, and the payload parameter has
    # the new value.
    print(f"Feed {feed_id} received new value: {payload}")


# Connect to WiFi
print("Connecting to WiFi...")
wifi.connect()
print("Connected!")

pool = adafruit_connection_manager.get_radio_socketpool(esp)
ssl_context = adafruit_connection_manager.get_radio_ssl_context(esp)

# Initialize a new MQTT Client object
mqtt_client = MQTT.MQTT(
    broker="io.adafruit.com",
    port=1883,
    username=aio_username,
    password=aio_key,
    socket_pool=pool,
    ssl_context=ssl_context,
)

# Initialize an Adafruit IO MQTT Client
io = IO_MQTT(mqtt_client)

# Connect the callback methods defined above to Adafruit IO
io.on_connect = connected
io.on_disconnect = disconnected
io.on_message = message
io.on_publish = publish

# Connect to Adafruit IO
io.connect()


# Start a blocking message loop...
# NOTE: This loop runs indefinitely until interrupted with Ctrl-C (KeyboardInterrupt).
# NOTE: Network reconnection is handled within this loop; cleanup runs afterward.
TIME_TOPICS = ("seconds", "millis", "iso", "hours")

try:
    while True:
        try:
            io.loop()
        except (ValueError, RuntimeError) as e:
            print("Failed to get data, retrying\n", e)
            io.reconnect()
            continue
        print("Use Ctrl-C to unsubscribe and disconnect...")
        time.sleep(1)
    # Normal loop ends here. Use Ctrl-C to Unsubscribe and disconnect/exit.

except KeyboardInterrupt:
    try:
        print("\nKeyboardInterrupt: processing pending messages before disconnecting...")
        io.loop()
    except Exception:
        pass
    print("\nUnsubscribing from time topics and disconnecting...")
    for time_topic in TIME_TOPICS:
        try:
            print(f"Unsubscribing from time topic '{time_topic}'...")
            io.unsubscribe_from_time(time_topic)
            print(f"Successfully unsubscribed from time topic '{time_topic}'.")
        except Exception as e:
            print(f"Failed to unsubscribe from time topic '{time_topic}':", e)
        try:
            print("Processing messages... (io.loop())")
            io.loop()
            print("Processing complete.")
        except Exception:
            pass
    # loop for another 6s collecting io loop messages
    print("Processing final messages for 6 seconds...")
    for _ in range(6):
        try:
            io.loop()
        except Exception as e:
            print("Failed to get data, retrying\n", e)
            continue
        time.sleep(1)
    io.disconnect()
